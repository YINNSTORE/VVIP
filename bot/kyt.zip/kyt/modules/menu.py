from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:start|/ssh)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("🔰 𝗦𝗦𝗛 𝗠𝗔𝗡𝗔𝗚𝗘𝗥 🔰","ssh")],
[Button.inline("🔰 𝗩𝗠𝗘𝗦𝗦 𝗠𝗔𝗡𝗔𝗚𝗘𝗥 🔰","vmess"),
Button.inline("🔰 𝗩𝗟𝗘𝗦𝗦 𝗠𝗔𝗡𝗔𝗚𝗘𝗥 🔰","vless")],
[Button.inline("🔰 𝗧𝗥𝗢𝗝𝗔𝗡 𝗠𝗔𝗡𝗔𝗚𝗘𝗥 🔰","trojan"),
Button.inline("🔰 𝗦𝗛𝗗𝗪𝗦𝗞 𝗠𝗔𝗡𝗔𝗚𝗘𝗥 🔰","shadowsocks")],
[Button.inline("🖥️ 𝗖𝗛𝗘𝗖𝗞 𝗩𝗣𝗦 𝗜𝗡𝗙𝗢 🖥️","info"),
Button.inline("🔧 𝗢𝗧𝗛𝗘𝗥 𝗦𝗘𝗧𝗧𝗜𝗡𝗚 🔧","setting")],
[Button.inline(" ↩️ 𝗕𝗮𝗰𝗸 𝗠𝗲𝗻𝘂 ↪️ ","start")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("📵 Akses Ditolak 📵", alert=True)
		except:
			await event.reply("📵 Akses Ditolak 📵")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
⊜━━━━━━━━━━━━━━━━━━━━━━⊜ 
**⭐ ADMIN PANEL MENU ⭐**
⊜━━━━━━━━━━━━━━━━━━━━━━⊜ 
**» OS     :** `{namaos.strip().replace('"','')}`
**» CITY :** `{city.strip()}`
**» DOMAIN :** `{DOMAIN}`
**» IP VPS :** `{ipsaya.strip()}`
**» Total Account Created:** 

**» ☢️SSH OVPN     :** `{ssh.strip()}` __account__
**» ☣️XRAY VMESS  :** `{vms.strip()}` __account__
**» ☢️XRAY VLESS   :** `{vls.strip()}` __account__
**» ☣️XRAY TROJAN :** `{trj.strip()}` __account__
⊜━━━━━━━━━━━━━━━━━━━━━━⊜ 
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


